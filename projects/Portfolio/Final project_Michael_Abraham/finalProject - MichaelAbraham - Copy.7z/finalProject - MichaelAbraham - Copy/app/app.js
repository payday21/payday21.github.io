//React libraries
import React from 'react';
import ReactDOM from 'react-dom';

//Import Container component
import AppContainer from './containers/app.container'

class App extends React.Component {
  render () {
    return (
      

      <Router>
        
        <div id="main-content">
          
            <Switch>
              <Route path="/signin" component={ SignIn } />
              <AppContainer />
            </Switch>
        </div>
      
    </Router>
    );
  }
}

// Render to index.html
ReactDOM.render(
  <App />,
  document.getElementById('content')
);
