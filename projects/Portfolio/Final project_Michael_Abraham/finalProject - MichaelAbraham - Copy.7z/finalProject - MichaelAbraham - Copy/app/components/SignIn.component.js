
import React from 'react';
import '../css/signin.css';
import Joi from 'joi-browser';
import AuthService from '../services/AuthService'


class SignIn extends React.Component {
    constructor(props){
        super(props)
    }

     
    render(){
        return
    }
}
export default SignIn
import React from 'react';
import '../css/signin.css';
import Joi from 'joi-browser';
import AuthService from '../services/AuthService'



class SignIn extends React.Component {

    state = {
        
        credentials: {
            email:'',
            password:''

        },
        errors: []
        
    
    }    
    schema = {
        email: Joi.string().required(),
        password: Joi.string().required()
    }     
        
       
 

        handleSubmit = (event) => {
        //    alert('A name was submitted ' + this.state.value);
            event.preventDefault();

            //validate 
            const result = Joi.validate(this.state.credentials, this.schema, {abortEarly: false})
            if(result.error){
                const errors = [];
                result.error.details.forEach(detail => {
                    const error = {}
                    error.message = detail.message
                    error.field = detail.path[0]                    
                
                    errors.push(error)
                })        
                //build entries in our error stat
                this.setState({errors})
            }       

            AuthService.login(this.state.credentials, success => {
                
                if(success) { this.props.history.push('/')}// redirect
                else {
                    //show some error message on the signin page
                    console.log('Could not login')                    
                }
            })              
        }
        
        handleChange = (event)=> 
        {
            //updating our state with the change in the form
            const { name, value } = event.target;

            const credentials = {...this.state.credentials}
            credentials[name] = value
           
            this.setState({ credentials })
        }


    
        render() 
        {
           
            return ( 
                // AuthService.isAuthenticated() ?
                //     <Redirect to='/' />
                // :
           
                <form onSubmit={this.handleSubmit} className="form-signin">
                     <fieldset className="col-md-12">
                        <legend className="col-md-12">Please sign in</legend>
                    {/* <h1 className="h3 mb-3 font-weight-normal text-center">Please sign in</h1> */}
                    <label htmlFor="inputEmail" className="sr-only">Email address</label>
                    <input onChange={this.handleChange}
                        name="email" 
                        type="email" value={this.state.value} 
                        id="inputEmail" className="form-control" 
                        placeholder="Email address"  />

                        {
                        this.state.errors.filter(error => error.field ==="email").length > 0
                            &&
                        <small>
                            <ul className="mb-0">
                                {this.state.errors
                                .filter(error => error.field === "email")
                                .map((error, i) => {
                                    return <li key={i}>{ error.message }</li>

                                }) 
                                } 
                            </ul>
                       </small>
                       }<br></br>

                        
                    <label htmlFor="inputPassword" className="sr-only">Password</label>
                    <input  onChange={this.handleChange}
                        name="password" 
                        type="password"  
                        id="inputPassword" 
                        className="form-control" 
                        placeholder="Password" />
                        {
                    this.state.errors.filter(error => error.field ==="password").length > 0
                            &&
                        <small>
                            <ul className="mb-0">
                                {this.state.errors
                                .filter(error => error.field === "password")
                                .map((error, i) => {
                                    return <li key={i}>{ error.message }</li>

                                }) 
                                } 
                            </ul>
                       </small>
                       }<br></br>
                    <button className="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
                    </fieldset>
                    
                </form>
                
                
            );
        }
    
    
}

    
    

 
export default SignIn;