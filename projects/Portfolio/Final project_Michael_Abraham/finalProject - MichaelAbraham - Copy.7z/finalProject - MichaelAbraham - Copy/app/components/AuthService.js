import DataService from './DataService'
import {Redirect} from 'react-router-dom'
import jwt from './AuthService'



class AuthService {
  //setting, reading and removing tokens from brownser
    
    //token related method
    getToken(){
      const token = localStorage.getItem('x-auth-token');     
      return token
    }

    setToken(token){
      localStorage.setItem('x-auth-token', token)

    }

    

    login(credentials, callback) 
    {

      DataService.login(credentials, (err, token) => {
       
        //set the jwt token
        if(err){
          callback(false);
          return;
        }
        console.log(token)
        
        // console.log(this.getUserToken())
        // this.setUserToken(this.getUserToken());

        this.setToken(token);

        callback(true);
        this.authenticated = true;   
          
      });
     
    }

    getEmail() {
      const token =  this.getToken().split('.')[1];
      const userEmail = Buffer.from(token, 'base64').toString()
       
      return JSON.parse(userEmail).name
    }
  
   
  
    isAuthenticated() {
      return this.getToken() !== null;
    }

    register(credentials, callback)
    {    
      //another api call....
      // callback(err, result);//jwt
      DataService.register(credentials, (err, token) => {
        //set the jwt token
        if(err){
          callback(err);
          return;
        }
        console.log(token)
        this.setToken(token);
        callback(null);      
          
      });
         
    }
    
    createAutomobile(credentials, callback){
      DataService.createAutomobile(credentials, this.getToken(), (err, data) => {
        if(err){
          callback(false);
          return;
        }
        console.log(data);
        callback(true);
      });
    }   
    editAutomobile(credentials, callback){
      console.log(`auth Automobile ID -> ${credentials._id}`)
      DataService.updateAutomobile(credentials,(err,data) => {
        if(err) {
          callback(false);
          return;
        }
        callback(true);
      })
    }
  

  deleteById(id, callback){
    DataService.deleteAutomobile(id, this.getToken(), (err, data) => {
      if(err){
        callback(false);
        return;
      }
      console.log(data);
      callback(true);

    });
  }

}
  export default new AuthService();
  