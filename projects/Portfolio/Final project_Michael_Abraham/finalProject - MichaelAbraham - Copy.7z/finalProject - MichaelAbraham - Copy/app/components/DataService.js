import Axios from 'axios';

class DataService {

    constructor(){
        this.apiURL = process.env.REACT_APP_API_URL;
    }

    getAutomobile(callback){

        Axios.get(`${this.apiURL}/automobile`)
        .then(response => {
            callback(null, response.data)
            console.log('response.data')
        
        })
        .catch(error => {
        console.log(Error)
        callback(error, null)
        })
    }    

    createAutomobile(credentials, token, callback){
        console.log(`TOKEN:${token}`)
        Axios.post(`${this.apiURL}/automobile`, credentials, 
            {
                headers:
                    {
                        'x-auth-token': token
                    }
             })
                    .then(response => callback(null, response.data))
                    .catch(err => callback(err, null))

    }


    getAutomobileById(id,callback){
        Axios.get(`${this.apiURL}/automobile/${id}`)
        .then(response => {
            console.log(response.data)
            callback(null, response.data)
            // console.log(response.data)
        
        })
        .catch(error => {
            console.log(Error)
            callback(error, null)
        })        
    }

    searchAutomobile(bodyType,callback){
        console.log('searchAutomobile method...')
        Axios.get(`${this.apiURL}/automobile/search/bodyType/${bodyType}`) 
        .then(response => {
            console.log('searchAutomobile method response...')
            callback(response.data)
            console.log(response.data)        
        })
        .catch(error => {
        console.log(error)
        callback(error)
        })        
    }

    updateAutomobile(credentials, token, callback){
        console.log(`data Automobile ID -> ${credentials._id}`)
        Axios.put(`${this.apiURL}/automobile/${credentials._id}`, credentials, 
        {
            headers:
            {
                'x-auth-token': token
            }
        })
        .then(response => callback(null, response.data))
        .catch(err => callback(err, null))        
    }

    deleteAutomobile(id, token, callback){        
        Axios.delete(`${this.apiURL}/automobile/${id}`, 
        {
            headers:
            {
                'x-auth-token': token
            }
        })
        .then(response => callback(true))
        .catch(err => callback(false))    
    }

    login(credentials, callback){
        Axios.post(`${this.apiURL}/users/login`, credentials)
        .then(response => callback(null, response.headers['x-auth-token']))
        .catch(err => callback(err, null))
    }

    register(credentials, callback)
    {
        Axios.post(`${this.apiURL}/users/register`, credentials)
                .then(response => callback(null, response.headers['x-auth-token']))
                .catch(err => {
                    //console.log(err.response)
                    callback(err.response, null)
                })

    }

    
}

export default new DataService();